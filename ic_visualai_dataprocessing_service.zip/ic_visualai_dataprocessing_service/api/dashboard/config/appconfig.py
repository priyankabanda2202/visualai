{
  "openai": {
    "apiKey": "LLMal64985FRoGa-/@GLD",
    "apiBase": "https://perf-dsmbrsvc.anthem.com/llmgateway/openai",
    "pemFile": r"C:\Users\AL56164\Downloads\root.pem"
  }
}