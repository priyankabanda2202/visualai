Sample readme for develop branch placeholder

